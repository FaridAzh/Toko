<?php
// ============================================
// KONFIGURASI KONEKSI DATABASE
// Sesuaikan dengan setting MySQL/XAMPP/Laragon Anda
// ============================================
session_start();

$host = "localhost";
$port = 8889;         // default port MySQL di MAMP (cek di MAMP > Preferences > Ports)
$user = "root";
$pass = "root";       // default username & password MySQL di MAMP adalah root/root
$dbname = "toko_online";

$koneksi = mysqli_connect($host, $user, $pass, $dbname, $port);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($koneksi, "utf8mb4");

// Fungsi bantu untuk membersihkan input
function clean($data) {
    global $koneksi;
    return mysqli_real_escape_string($koneksi, htmlspecialchars(trim($data)));
}

// Fungsi format rupiah
function rupiah($angka) {
    return "Rp " . number_format($angka, 0, ',', '.');
}
?>
