<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$transaksi = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE user_id = $user_id ORDER BY created_at DESC");

require_once 'includes/header.php';
?>

<h1>Riwayat Transaksi</h1>
<?php if (isset($_GET['sukses'])): ?>
    <p class="alert-success">Pesanan berhasil dibuat!</p>
<?php endif; ?>

<?php if (mysqli_num_rows($transaksi) == 0): ?>
    <p>Belum ada transaksi.</p>
<?php else: ?>
    <?php while ($t = mysqli_fetch_assoc($transaksi)): ?>
        <div class="card-transaksi">
            <p><strong>Transaksi #<?= $t['id'] ?></strong> — <?= date('d M Y, H:i', strtotime($t['created_at'])) ?></p>
            <p>Status: <span class="status-<?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></p>
            <p>Total: <?= rupiah($t['total_harga']) ?></p>
            <details>
                <summary>Lihat Detail</summary>
                <ul>
                    <?php
                    $detail = mysqli_query($koneksi, "SELECT * FROM transaksi_detail WHERE transaksi_id = {$t['id']}");
                    while ($d = mysqli_fetch_assoc($detail)):
                    ?>
                        <li><?= htmlspecialchars($d['nama_produk']) ?> x <?= $d['jumlah'] ?> = <?= rupiah($d['subtotal']) ?></li>
                    <?php endwhile; ?>
                </ul>
            </details>
        </div>
    <?php endwhile; ?>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
