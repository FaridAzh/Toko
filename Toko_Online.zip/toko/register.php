<?php
require_once 'config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = clean($_POST['nama']);
    $email = clean($_POST['email']);
    $password = $_POST['password'];

    $cek = mysqli_query($koneksi, "SELECT id FROM users WHERE email = '$email'");
    if (mysqli_num_rows($cek) > 0) {
        $error = "Email sudah terdaftar.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (nama, email, password, role) VALUES ('$nama', '$email', '$hash', 'customer')";
        if (mysqli_query($koneksi, $sql)) {
            header("Location: login.php?registered=1");
            exit;
        } else {
            $error = "Gagal mendaftar: " . mysqli_error($koneksi);
        }
    }
}

require_once 'includes/header.php';
?>

<div class="form-box">
    <h2>Daftar Akun</h2>
    <?php if ($error): ?><p class="alert-error"><?= $error ?></p><?php endif; ?>
    <form method="POST">
        <label>Nama Lengkap</label>
        <input type="text" name="nama" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required minlength="6">

        <button type="submit">Daftar</button>
    </form>
    <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
</div>

<?php require_once 'includes/footer.php'; ?>
