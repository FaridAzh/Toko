-- ============================================
-- DATABASE: toko_online
-- Jalankan file ini di phpMyAdmin / MySQL
-- ============================================

CREATE DATABASE IF NOT EXISTS toko_online;
USE toko_online;

-- Tabel pengguna (admin & customer)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel kategori barang
CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL
);

-- Tabel barang/produk
CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kategori_id INT,
    nama_produk VARCHAR(150) NOT NULL,
    deskripsi TEXT,
    harga DECIMAL(12,2) NOT NULL,
    stok INT DEFAULT 0,
    gambar VARCHAR(255) DEFAULT 'no-image.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE SET NULL
);

-- Tabel transaksi (header)
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_harga DECIMAL(12,2) NOT NULL,
    status ENUM('pending','dibayar','dikirim','selesai','batal') DEFAULT 'pending',
    alamat_kirim TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Tabel detail transaksi (item per transaksi)
CREATE TABLE IF NOT EXISTS transaksi_detail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaksi_id INT NOT NULL,
    produk_id INT NOT NULL,
    nama_produk VARCHAR(150) NOT NULL,
    harga_satuan DECIMAL(12,2) NOT NULL,
    jumlah INT NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE,
    FOREIGN KEY (produk_id) REFERENCES produk(id)
);

-- ============================================
-- DATA CONTOH
-- ============================================

-- Admin default (password: admin123)
INSERT INTO users (nama, email, password, role) VALUES
('Administrator', 'admin@toko.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- Catatan: hash di atas adalah contoh, sebaiknya buat ulang lewat register.php

-- Kategori contoh
INSERT INTO kategori (nama_kategori) VALUES
('Elektronik'),
('Pakaian'),
('Aksesoris'),
('Sepatu');

-- Produk contoh
INSERT INTO produk (kategori_id, nama_produk, deskripsi, harga, stok, gambar) VALUES
(1, 'Headphone Bluetooth', 'Headphone wireless dengan kualitas suara jernih', 250000, 20, 'no-image.png'),
(2, 'Kaos Polos Premium', 'Kaos berbahan katun combed 30s, nyaman dipakai', 75000, 50, 'no-image.png'),
(3, 'Tas Selempang Kulit', 'Tas selempang bahan kulit sintetis berkualitas', 150000, 15, 'no-image.png'),
(4, 'Sepatu Sneakers Casual', 'Sepatu casual cocok untuk harian', 320000, 10, 'no-image.png');
