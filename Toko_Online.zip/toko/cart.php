<?php
require_once 'config.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Tambah ke keranjang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_keranjang'])) {
    $produk_id = (int)$_POST['produk_id'];
    $jumlah = max(1, (int)$_POST['jumlah']);

    $row = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $produk_id"));
    if ($row) {
        if (isset($_SESSION['cart'][$produk_id])) {
            $_SESSION['cart'][$produk_id]['jumlah'] += $jumlah;
        } else {
            $_SESSION['cart'][$produk_id] = [
                'nama_produk' => $row['nama_produk'],
                'harga' => $row['harga'],
                'jumlah' => $jumlah,
                'gambar' => $row['gambar']
            ];
        }
    }
    header("Location: cart.php");
    exit;
}

// Hapus item dari keranjang
if (isset($_GET['hapus'])) {
    unset($_SESSION['cart'][(int)$_GET['hapus']]);
    header("Location: cart.php");
    exit;
}

// Update jumlah
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        if ((int)$qty > 0 && isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['jumlah'] = (int)$qty;
        }
    }
    header("Location: cart.php");
    exit;
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['harga'] * $item['jumlah'];
}

require_once 'includes/header.php';
?>

<h1>Keranjang Belanja</h1>

<?php if (empty($_SESSION['cart'])): ?>
    <p>Keranjang Anda masih kosong. <a href="index.php">Belanja sekarang</a></p>
<?php else: ?>
    <form method="POST">
        <table class="cart-table">
            <tr>
                <th>Produk</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th><th>Aksi</th>
            </tr>
            <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['nama_produk']) ?></td>
                    <td><?= rupiah($item['harga']) ?></td>
                    <td><input type="number" name="qty[<?= $id ?>]" value="<?= $item['jumlah'] ?>" min="1" style="width:60px"></td>
                    <td><?= rupiah($item['harga'] * $item['jumlah']) ?></td>
                    <td><a href="cart.php?hapus=<?= $id ?>" onclick="return confirm('Hapus item ini?')">Hapus</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <button type="submit" name="update_qty">Update Jumlah</button>
    </form>

    <h3>Total: <?= rupiah($total) ?></h3>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="checkout.php" class="btn-checkout">Lanjut ke Checkout</a>
    <?php else: ?>
        <p>Silakan <a href="login.php">login</a> terlebih dahulu untuk checkout.</p>
    <?php endif; ?>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
