<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Toko Online</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="navbar">
    <div class="logo"><a href="index.php">🛍️ TokoKita</a></div>
    <nav>
        <a href="index.php">Beranda</a>
        <a href="cart.php">Keranjang
            <?php if(!empty($_SESSION['cart'])): ?>
                <span class="badge"><?= array_sum(array_column($_SESSION['cart'], 'jumlah')) ?></span>
            <?php endif; ?>
        </a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="admin/dashboard.php">Admin Panel</a>
            <?php else: ?>
                <a href="riwayat.php">Riwayat</a>
            <?php endif; ?>
            <a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['nama']) ?>)</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Daftar</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
