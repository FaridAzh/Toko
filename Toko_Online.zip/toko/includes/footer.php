</main>
<footer class="footer">
    <p>&copy; <?= date('Y') ?> TokoKita. Dibuat untuk keperluan pembelajaran.</p>
</footer>
</body>
</html>
