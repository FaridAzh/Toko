<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $alamat = clean($_POST['alamat']);
    $user_id = $_SESSION['user_id'];

    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['harga'] * $item['jumlah'];
    }

    mysqli_begin_transaction($koneksi);
    try {
        $sql = "INSERT INTO transaksi (user_id, total_harga, alamat_kirim, status) VALUES ($user_id, $total, '$alamat', 'pending')";
        mysqli_query($koneksi, $sql);
        $transaksi_id = mysqli_insert_id($koneksi);

        foreach ($_SESSION['cart'] as $produk_id => $item) {
            $subtotal = $item['harga'] * $item['jumlah'];
            $nama = mysqli_real_escape_string($koneksi, $item['nama_produk']);
            mysqli_query($koneksi, "INSERT INTO transaksi_detail (transaksi_id, produk_id, nama_produk, harga_satuan, jumlah, subtotal)
                VALUES ($transaksi_id, $produk_id, '$nama', {$item['harga']}, {$item['jumlah']}, $subtotal)");

            // Kurangi stok
            mysqli_query($koneksi, "UPDATE produk SET stok = stok - {$item['jumlah']} WHERE id = $produk_id");
        }

        mysqli_commit($koneksi);
        $_SESSION['cart'] = [];
        header("Location: riwayat.php?sukses=1");
        exit;
    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        $error = "Checkout gagal: " . $e->getMessage();
    }
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['harga'] * $item['jumlah'];
}

require_once 'includes/header.php';
?>

<h1>Checkout</h1>
<?php if ($error): ?><p class="alert-error"><?= $error ?></p><?php endif; ?>

<h3>Ringkasan Pesanan</h3>
<ul>
    <?php foreach ($_SESSION['cart'] as $item): ?>
        <li><?= htmlspecialchars($item['nama_produk']) ?> x <?= $item['jumlah'] ?> = <?= rupiah($item['harga'] * $item['jumlah']) ?></li>
    <?php endforeach; ?>
</ul>
<h3>Total: <?= rupiah($total) ?></h3>

<form method="POST">
    <label>Alamat Pengiriman</label>
    <textarea name="alamat" required rows="3" placeholder="Masukkan alamat lengkap"></textarea>
    <button type="submit">Konfirmasi Pesanan</button>
</form>

<?php require_once 'includes/footer.php'; ?>
