<?php
require_once 'auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id = (int)$_POST['id'];
    $status = clean($_POST['status']);
    mysqli_query($koneksi, "UPDATE transaksi SET status = '$status' WHERE id = $id");
    header("Location: transaksi.php?update=1");
    exit;
}

$transaksi = mysqli_query($koneksi, "SELECT t.*, u.nama, u.email FROM transaksi t
                                      JOIN users u ON t.user_id = u.id
                                      ORDER BY t.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Transaksi - Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">Dashboard</a>
        <a href="produk.php">Kelola Produk</a>
        <a href="kategori.php">Kelola Kategori</a>
        <a href="transaksi.php" class="active">Kelola Transaksi</a>
        <a href="../index.php">Lihat Toko</a>
        <a href="../logout.php">Logout</a>
    </aside>
    <main class="admin-content">
        <h1>Kelola Transaksi</h1>
        <?php if (isset($_GET['update'])): ?><p class="alert-success">Status berhasil diperbarui.</p><?php endif; ?>

        <table class="cart-table">
            <tr><th>ID</th><th>Pelanggan</th><th>Total</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr>
            <?php while ($t = mysqli_fetch_assoc($transaksi)): ?>
                <tr>
                    <td>#<?= $t['id'] ?></td>
                    <td><?= htmlspecialchars($t['nama']) ?><br><small><?= htmlspecialchars($t['email']) ?></small></td>
                    <td><?= rupiah($t['total_harga']) ?></td>
                    <td><span class="status-<?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></td>
                    <td><?= date('d M Y, H:i', strtotime($t['created_at'])) ?></td>
                    <td>
                        <form method="POST" style="display:flex; gap:4px;">
                            <input type="hidden" name="id" value="<?= $t['id'] ?>">
                            <select name="status">
                                <?php foreach (['pending','dibayar','dikirim','selesai','batal'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $t['status'] == $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="update_status">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>
</div>
</body>
</html>
