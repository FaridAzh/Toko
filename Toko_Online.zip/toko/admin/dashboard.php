<?php
require_once 'auth.php';

$total_produk = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS jml FROM produk"))['jml'];
$total_transaksi = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS jml FROM transaksi"))['jml'];
$total_pendapatan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) AS jml FROM transaksi WHERE status != 'batal'"))['jml'] ?? 0;
$total_user = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS jml FROM users WHERE role = 'customer'"))['jml'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Admin Panel - Toko Online</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="produk.php">Kelola Produk</a>
        <a href="kategori.php">Kelola Kategori</a>
        <a href="transaksi.php">Kelola Transaksi</a>
        <a href="../index.php">Lihat Toko</a>
        <a href="../logout.php">Logout</a>
    </aside>
    <main class="admin-content">
        <h1>Dashboard</h1>
        <div class="stat-grid">
            <div class="stat-box"><h3><?= $total_produk ?></h3><p>Total Produk</p></div>
            <div class="stat-box"><h3><?= $total_transaksi ?></h3><p>Total Transaksi</p></div>
            <div class="stat-box"><h3><?= rupiah($total_pendapatan) ?></h3><p>Total Pendapatan</p></div>
            <div class="stat-box"><h3><?= $total_user ?></h3><p>Total Pelanggan</p></div>
        </div>
    </main>
</div>
</body>
</html>
