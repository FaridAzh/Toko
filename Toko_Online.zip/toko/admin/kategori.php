<?php
require_once 'auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $nama = clean($_POST['nama_kategori']);
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        mysqli_query($koneksi, "UPDATE kategori SET nama_kategori = '$nama' WHERE id = $id");
    } else {
        mysqli_query($koneksi, "INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
    }
    header("Location: kategori.php?sukses=1");
    exit;
}

if (isset($_GET['hapus'])) {
    mysqli_query($koneksi, "DELETE FROM kategori WHERE id = " . (int)$_GET['hapus']);
    header("Location: kategori.php?hapus=1");
    exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM kategori WHERE id = " . (int)$_GET['edit']));
}

$kategori = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Kategori - Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">Dashboard</a>
        <a href="produk.php">Kelola Produk</a>
        <a href="kategori.php" class="active">Kelola Kategori</a>
        <a href="transaksi.php">Kelola Transaksi</a>
        <a href="../index.php">Lihat Toko</a>
        <a href="../logout.php">Logout</a>
    </aside>
    <main class="admin-content">
        <h1>Kelola Kategori</h1>
        <?php if (isset($_GET['sukses'])): ?><p class="alert-success">Data berhasil disimpan.</p><?php endif; ?>

        <form method="POST" class="form-box">
            <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" value="<?= htmlspecialchars($edit_data['nama_kategori'] ?? '') ?>" required>
            <button type="submit" name="simpan"><?= $edit_data ? 'Update' : 'Tambah' ?></button>
            <?php if ($edit_data): ?><a href="kategori.php">Batal</a><?php endif; ?>
        </form>

        <table class="cart-table">
            <tr><th>Nama Kategori</th><th>Aksi</th></tr>
            <?php while ($k = mysqli_fetch_assoc($kategori)): ?>
                <tr>
                    <td><?= htmlspecialchars($k['nama_kategori']) ?></td>
                    <td>
                        <a href="kategori.php?edit=<?= $k['id'] ?>">Edit</a> |
                        <a href="kategori.php?hapus=<?= $k['id'] ?>" onclick="return confirm('Hapus kategori ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>
</div>
</body>
</html>
