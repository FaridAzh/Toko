<?php
require_once 'auth.php';

$msg = '';

// Tambah / Edit produk
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id = (int)($_POST['id'] ?? 0);
    $nama = clean($_POST['nama_produk']);
    $kategori_id = (int)$_POST['kategori_id'];
    $deskripsi = clean($_POST['deskripsi']);
    $harga = (float)$_POST['harga'];
    $stok = (int)$_POST['stok'];
    $gambar = 'no-image.png';

    // Upload gambar jika ada
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === 0) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $gambar = 'produk_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../uploads/' . $gambar);
    }

    if ($id > 0) {
        $sqlGambar = isset($_FILES['gambar']) && $_FILES['gambar']['error'] === 0 ? ", gambar = '$gambar'" : "";
        $sql = "UPDATE produk SET nama_produk='$nama', kategori_id=$kategori_id, deskripsi='$deskripsi',
                harga=$harga, stok=$stok $sqlGambar WHERE id=$id";
    } else {
        $sql = "INSERT INTO produk (nama_produk, kategori_id, deskripsi, harga, stok, gambar)
                VALUES ('$nama', $kategori_id, '$deskripsi', $harga, $stok, '$gambar')";
    }
    mysqli_query($koneksi, $sql);
    header("Location: produk.php?sukses=1");
    exit;
}

// Hapus produk
if (isset($_GET['hapus'])) {
    mysqli_query($koneksi, "DELETE FROM produk WHERE id = " . (int)$_GET['hapus']);
    header("Location: produk.php?hapus=1");
    exit;
}

// Ambil data untuk form edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM produk WHERE id = " . (int)$_GET['edit']));
}

$produk = mysqli_query($koneksi, "SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.kategori_id = k.id ORDER BY p.id DESC");
$kategoriList = mysqli_query($koneksi, "SELECT * FROM kategori");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Produk - Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">Dashboard</a>
        <a href="produk.php" class="active">Kelola Produk</a>
        <a href="kategori.php">Kelola Kategori</a>
        <a href="transaksi.php">Kelola Transaksi</a>
        <a href="../index.php">Lihat Toko</a>
        <a href="../logout.php">Logout</a>
    </aside>
    <main class="admin-content">
        <h1>Kelola Produk</h1>
        <?php if (isset($_GET['sukses'])): ?><p class="alert-success">Data berhasil disimpan.</p><?php endif; ?>
        <?php if (isset($_GET['hapus'])): ?><p class="alert-success">Produk berhasil dihapus.</p><?php endif; ?>

        <h3><?= $edit_data ? 'Edit Produk' : 'Tambah Produk Baru' ?></h3>
        <form method="POST" enctype="multipart/form-data" class="form-box">
            <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
            <label>Nama Produk</label>
            <input type="text" name="nama_produk" value="<?= htmlspecialchars($edit_data['nama_produk'] ?? '') ?>" required>

            <label>Kategori</label>
            <select name="kategori_id" required>
                <?php mysqli_data_seek($kategoriList, 0); while ($k = mysqli_fetch_assoc($kategoriList)): ?>
                    <option value="<?= $k['id'] ?>" <?= ($edit_data['kategori_id'] ?? 0) == $k['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($k['nama_kategori']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label>Deskripsi</label>
            <textarea name="deskripsi" rows="3"><?= htmlspecialchars($edit_data['deskripsi'] ?? '') ?></textarea>

            <label>Harga</label>
            <input type="number" name="harga" value="<?= $edit_data['harga'] ?? '' ?>" required>

            <label>Stok</label>
            <input type="number" name="stok" value="<?= $edit_data['stok'] ?? '' ?>" required>

            <label>Gambar Produk</label>
            <input type="file" name="gambar" accept="image/*">

            <button type="submit" name="simpan"><?= $edit_data ? 'Update' : 'Simpan' ?></button>
            <?php if ($edit_data): ?><a href="produk.php">Batal</a><?php endif; ?>
        </form>

        <h3>Daftar Produk</h3>
        <table class="cart-table">
            <tr><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr>
            <?php while ($p = mysqli_fetch_assoc($produk)): ?>
                <tr>
                    <td><?= htmlspecialchars($p['nama_produk']) ?></td>
                    <td><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></td>
                    <td><?= rupiah($p['harga']) ?></td>
                    <td><?= $p['stok'] ?></td>
                    <td>
                        <a href="produk.php?edit=<?= $p['id'] ?>">Edit</a> |
                        <a href="produk.php?hapus=<?= $p['id'] ?>" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>
</div>
</body>
</html>
