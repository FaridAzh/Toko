<?php
require_once 'config.php';

// Ambil parameter pencarian & filter kategori (opsional)
$keyword = isset($_GET['q']) ? clean($_GET['q']) : '';
$kategori_id = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;

$sql = "SELECT p.*, k.nama_kategori FROM produk p
        LEFT JOIN kategori k ON p.kategori_id = k.id
        WHERE 1=1";

if ($keyword !== '') {
    $sql .= " AND p.nama_produk LIKE '%$keyword%'";
}
if ($kategori_id > 0) {
    $sql .= " AND p.kategori_id = $kategori_id";
}
$sql .= " ORDER BY p.created_at DESC";

$result = mysqli_query($koneksi, $sql);
$kategoriList = mysqli_query($koneksi, "SELECT * FROM kategori");

require_once 'includes/header.php';
?>

<h1>Daftar Produk</h1>

<form method="GET" class="filter-bar">
    <input type="text" name="q" placeholder="Cari produk..." value="<?= htmlspecialchars($keyword) ?>">
    <select name="kategori">
        <option value="0">Semua Kategori</option>
        <?php while ($k = mysqli_fetch_assoc($kategoriList)): ?>
            <option value="<?= $k['id'] ?>" <?= $kategori_id == $k['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($k['nama_kategori']) ?>
            </option>
        <?php endwhile; ?>
    </select>
    <button type="submit">Cari</button>
</form>

<div class="product-grid">
    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="card">
                <img src="uploads/<?= htmlspecialchars($row['gambar']) ?>" alt="<?= htmlspecialchars($row['nama_produk']) ?>" onerror="this.src='uploads/no-image.png'">
                <h3><?= htmlspecialchars($row['nama_produk']) ?></h3>
                <p class="kategori-label"><?= htmlspecialchars($row['nama_kategori'] ?? '-') ?></p>
                <p class="harga"><?= rupiah($row['harga']) ?></p>
                <p class="stok">Stok: <?= $row['stok'] ?></p>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="produk_id" value="<?= $row['id'] ?>">
                    <input type="number" name="jumlah" value="1" min="1" max="<?= $row['stok'] ?>" style="width:60px">
                    <button type="submit" name="tambah_keranjang" <?= $row['stok'] == 0 ? 'disabled' : '' ?>>
                        <?= $row['stok'] == 0 ? 'Stok Habis' : 'Tambah ke Keranjang' ?>
                    </button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Produk tidak ditemukan.</p>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
